document.addEventListener("DOMContentLoaded", function () {
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            let name = document.getElementById("name").value;
            let email = document.getElementById("email").value;
            let message = document.getElementById("message").value;
            let error = document.getElementById("errorMessage");

            error.textContent = "";

            if (name === "" || email === "" || message === "") {
                error.textContent = "All fields are required.";
                event.preventDefault();
                return;
            }

            if (!email.includes("@")) {
                error.textContent = "Please enter a valid email address.";
                event.preventDefault();
                return;
            }

            alert("Form submitted successfully!");
        });
    }

    const navbar = document.querySelector(".navbar");
    const navToggle = document.querySelector(".nav-toggle");
    const navMenu = document.getElementById("navMenu");
    const dropdown = document.querySelector(".dropdown");
    const dropdownToggle = document.querySelector(".dropdown-toggle");

    function closeDropdown() {
        if (!dropdown) return;
        dropdown.classList.remove("open");
        if (dropdownToggle) dropdownToggle.setAttribute("aria-expanded", "false");
    }

    function closeMobileMenu() {
        if (!navbar) return;
        navbar.classList.remove("menu-open");
        if (navToggle) navToggle.setAttribute("aria-expanded", "false");
    }

    if (navToggle && navbar && navMenu) {
        navToggle.addEventListener("click", function () {
            const isOpen = navbar.classList.toggle("menu-open");
            navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
            if (!isOpen) closeDropdown();
        });
    }

    if (dropdown && dropdownToggle) {
        dropdownToggle.addEventListener("click", function () {
            const isOpen = dropdown.classList.toggle("open");
            dropdownToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });
    }

    document.addEventListener("click", function (event) {
        const target = event.target;
        const clickedInsideNavbar = navbar && navbar.contains(target);
        const clickedInsideDropdown = dropdown && dropdown.contains(target);

        if (!clickedInsideDropdown) closeDropdown();
        if (!clickedInsideNavbar) closeMobileMenu();
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            closeDropdown();
            closeMobileMenu();
        }
    });

    const navLinks = document.querySelectorAll(".nav-menu a");
    navLinks.forEach(function (link) {
        link.addEventListener("click", function () {
            closeDropdown();
            closeMobileMenu();
        });
    });
});
function loadData() {
    const output = document.getElementById("ajaxResult");
    if (!output) return;

    output.innerText = "Loading...";

    fetch("data.txt", { cache: "no-store" })
        .then((response) => {
            if (!response.ok) {
                throw new Error("HTTP " + response.status);
            }
            return response.text();
        })
        .then((data) => {
            output.innerText = data;
        })
        .catch(() => {
            output.innerText = "Could not load data.txt. If you opened the HTML using file://, fetch may be blocked. Run with a local server.";
        });
}
